--
-- PostgreSQL database dump
--

\restrict vtXgumJufkuNrEQ0qh2H8u9gfPz3S0pjcAqIVswgwvwfdbcg6FIrqpnwg88Xfus

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: session_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.session_status AS ENUM (
    'draft',
    'completed',
    'archived'
);


ALTER TYPE public.session_status OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'peer_support',
    'admin'
);


ALTER TYPE public.user_role OWNER TO postgres;

--
-- Name: audit_trigger_function(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.audit_trigger_function() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    audit_user_id UUID;
BEGIN
    -- Get user_id from session if available
    audit_user_id := current_setting('app.current_user_id', true)::UUID;
    
    IF TG_OP = 'DELETE' THEN
        INSERT INTO audit_logs (user_id, table_name, record_id, action, old_values)
        VALUES (audit_user_id, TG_TABLE_NAME, OLD.id, 'DELETE', row_to_json(OLD));
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_logs (user_id, table_name, record_id, action, old_values, new_values)
        VALUES (audit_user_id, TG_TABLE_NAME, NEW.id, 'UPDATE', row_to_json(OLD), row_to_json(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'INSERT' THEN
        INSERT INTO audit_logs (user_id, table_name, record_id, action, new_values)
        VALUES (audit_user_id, TG_TABLE_NAME, NEW.id, 'INSERT', row_to_json(NEW));
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.audit_trigger_function() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    table_name character varying(50) NOT NULL,
    record_id uuid NOT NULL,
    action character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: TABLE audit_logs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.audit_logs IS 'HIPAA compliance audit trail for all data access and changes';


--
-- Name: COLUMN audit_logs.action; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_logs.action IS 'Type of action: INSERT, UPDATE, DELETE, or VIEW';


--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    first_name character varying(100) NOT NULL,
    last_initial character(1) NOT NULL,
    treatment_plan text,
    date_of_birth date,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    objectives_selected jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: TABLE clients; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.clients IS 'Client records with HIPAA-compliant minimal data storage';


--
-- Name: COLUMN clients.last_initial; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clients.last_initial IS 'HIPAA: Store only last initial, not full last name';


--
-- Name: COLUMN clients.objectives_selected; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clients.objectives_selected IS 'Array of objective IDs pre-selected for this client profile';


--
-- Name: session_locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session_locations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.session_locations OWNER TO postgres;

--
-- Name: session_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session_notes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid NOT NULL,
    session_date date NOT NULL,
    duration_minutes integer NOT NULL,
    location_id uuid,
    location_other character varying(200),
    generated_note text NOT NULL,
    custom_feedback text,
    status public.session_status DEFAULT 'draft'::public.session_status,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT session_date_not_future CHECK ((session_date <= CURRENT_DATE)),
    CONSTRAINT session_notes_duration_minutes_check CHECK ((duration_minutes > 0))
);


ALTER TABLE public.session_notes OWNER TO postgres;

--
-- Name: TABLE session_notes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.session_notes IS 'Generated session notes for billing and compliance';


--
-- Name: COLUMN session_notes.generated_note; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.session_notes.generated_note IS 'AI-generated session note content for billing';


--
-- Name: session_objectives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session_objectives (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    session_note_id uuid NOT NULL,
    objective_id uuid,
    custom_objective character varying(500),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT objective_or_custom CHECK ((((objective_id IS NOT NULL) AND (custom_objective IS NULL)) OR ((objective_id IS NULL) AND (custom_objective IS NOT NULL))))
);


ALTER TABLE public.session_objectives OWNER TO postgres;

--
-- Name: TABLE session_objectives; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.session_objectives IS 'Treatment objectives addressed in each session';


--
-- Name: treatment_objectives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treatment_objectives (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(200) NOT NULL,
    category character varying(100),
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.treatment_objectives OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255),
    password_hash character varying(255) NOT NULL,
    role public.user_role DEFAULT 'peer_support'::public.user_role NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    is_active boolean DEFAULT true,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.users IS 'User accounts for peer support staff and administrators';


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, table_name, record_id, action, old_values, new_values, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, first_name, last_initial, treatment_plan, date_of_birth, is_active, created_by, created_at, updated_at, objectives_selected) FROM stdin;
5a8f87ed-96f7-4c98-80ab-85ae81951a0b	John	D	Focus on coping skills development and medication compliance	\N	t	28224a49-6863-420f-9045-58a433948c9b	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03	[]
8b41e65d-7783-4128-ad9f-92ac1eb53535	Michael	R	Substance abuse recovery and employment readiness	\N	t	73496734-c379-43dd-a796-638f741e3694	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03	[]
95710986-677b-475f-b114-f2e1d8c7a85e	David	M	Crisis management and wellness planning	\N	t	28224a49-6863-420f-9045-58a433948c9b	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03	[]
fe6821fd-dbc4-4857-8ff2-1fa2c041f783	Lisa	K	Housing stability and financial management skills	\N	t	0f9f1311-91b7-4e4c-8330-0197264792de	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03	[]
162e89fd-aa44-4c45-a9a6-4d540a108d57	Robert	T	Peer support engagement and self-advocacy development	\N	t	73496734-c379-43dd-a796-638f741e3694	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03	[]
9ea2bd51-d522-4d45-b5f4-145ffa75e1d3	Emily	W	Educational goals and communication skills improvement	\N	t	3d721fc1-e812-49fa-848e-b5009a264a7c	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03	[]
a439184b-212b-48a8-8432-1f0cce93882d	test	T	test	\N	t	76c00b5d-8300-4482-934c-53496deed884	2025-09-14 12:47:07.505124+03	2025-09-14 12:47:07.505124+03	[]
a29fb89b-0afe-4d71-b9bc-208dbcbf297f	Dark	T	Long-term Goal 1: Improve overall mental health and well-being\n     Short-term Goal 1: Reduce anxiety symptoms\n     Intervention 1: Anxiety management - Client will practice breathing exercises and mindfulness techniques	\N	t	76c00b5d-8300-4482-934c-53496deed884	2025-11-05 21:32:17.620736+03	2025-11-05 22:55:34.108774+03	["a79169b4-bdfd-4d3d-88aa-5942ca8f089a", "78d4074f-ec31-480a-ab70-6feba6906c38"]
28c3ef76-53a6-4f26-9330-0820f7c7decb	Sarah	L	Trauma recovery and family relationship improvement	\N	t	3d721fc1-e812-49fa-848e-b5009a264a7c	2025-09-08 00:03:47.849171+03	2025-11-05 23:19:46.933368+03	["a79169b4-bdfd-4d3d-88aa-5942ca8f089a", "e5168de9-3fad-4a71-998c-5312a4fee9e6", "23f12f93-c3e4-48ce-9b4f-6143e2e02aa6", "7f2d8fef-1c7e-4505-ac01-f30b52f17532"]
1e1aad76-7156-4375-9b46-cf6d4789fcd5	Jane	S	Social skills development and community integration support	\N	t	0f9f1311-91b7-4e4c-8330-0197264792de	2025-09-08 00:03:47.849171+03	2025-11-05 23:19:57.135923+03	["a79169b4-bdfd-4d3d-88aa-5942ca8f089a", "e5168de9-3fad-4a71-998c-5312a4fee9e6", "78d4074f-ec31-480a-ab70-6feba6906c38", "a40f49ae-f36f-43bd-a8a9-55d8f19a5650", "d8d8b1f9-8839-4438-a748-09f17017cd0c"]
\.


--
-- Data for Name: session_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session_locations (id, name, description, is_active, created_at) FROM stdin;
5d483ab7-b10b-418e-9ccf-55c3cdd3f04b	Client Home	In-person session at client's residence	t	2025-09-08 00:03:47.849171+03
20af657b-b37a-48ab-91f2-89fd59581b1f	Telehealth	Remote session via video call or phone	t	2025-09-08 00:03:47.849171+03
cd8fffd2-38ff-4028-881f-db5123d4000b	Community	Session in community setting (park, cafe, etc.)	t	2025-09-08 00:03:47.849171+03
f65bd398-be42-4a15-b57a-e966371f27b8	Office	Session at agency office or clinical setting	t	2025-09-08 00:03:47.849171+03
75571a4f-f464-4120-b715-c6cea3a8afe3	Hospital	Session at hospital or medical facility	t	2025-09-08 00:03:47.849171+03
341231b0-44e6-4ed2-8473-7bb1e86fef3f	Group Home	Session at residential group home	t	2025-09-08 00:03:47.849171+03
36541a82-773f-4914-9ecf-02aa0b6edd1b	Outpatient Clinic	Session at outpatient treatment facility	t	2025-09-08 00:03:47.849171+03
\.


--
-- Data for Name: session_notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session_notes (id, client_id, user_id, session_date, duration_minutes, location_id, location_other, generated_note, custom_feedback, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session_objectives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session_objectives (id, session_note_id, objective_id, custom_objective, created_at) FROM stdin;
\.


--
-- Data for Name: treatment_objectives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treatment_objectives (id, name, category, description, is_active, created_at) FROM stdin;
184dc18d-f150-4c1e-8c8f-06c6a8f89581	Improve coping skills	Mental Health	\N	t	2025-09-08 00:03:47.849171+03
d2fb9cc8-6291-4ef0-a4f8-57ce70f31ee5	Medication compliance	Medical	\N	t	2025-09-08 00:03:47.849171+03
bcac5a1f-2a44-4b13-a8a8-6c6ea51c489d	Social skills development	Social	\N	t	2025-09-08 00:03:47.849171+03
e5168de9-3fad-4a71-998c-5312a4fee9e6	Employment readiness	Vocational	\N	t	2025-09-08 00:03:47.849171+03
240b131a-4c7d-40c5-9c6b-b6246136dd3c	Housing stability	Basic Needs	\N	t	2025-09-08 00:03:47.849171+03
07888944-12c3-4841-807a-5df6f55db208	Substance abuse recovery	Addiction	\N	t	2025-09-08 00:03:47.849171+03
017e7ab8-c3b9-4a93-9b38-b34de2b1c5a6	Crisis management	Mental Health	\N	t	2025-09-08 00:03:47.849171+03
8af175de-da5f-48c4-84de-1c3702816589	Family relationship improvement	Social	\N	t	2025-09-08 00:03:47.849171+03
a40f49ae-f36f-43bd-a8a9-55d8f19a5650	Financial management	Life Skills	\N	t	2025-09-08 00:03:47.849171+03
ca69a77f-688e-47e2-bef4-64eb0d02e139	Transportation assistance	Basic Needs	\N	t	2025-09-08 00:03:47.849171+03
e32773fe-bf1c-41d5-8132-e932be1e4270	Peer support engagement	Social	\N	t	2025-09-08 00:03:47.849171+03
39505276-85b8-4690-aaec-bad0edce8280	Self-advocacy skills	Empowerment	\N	t	2025-09-08 00:03:47.849171+03
eecf525c-9f6d-487a-accd-f1695c6affc4	Wellness planning	Mental Health	\N	t	2025-09-08 00:03:47.849171+03
2369efe1-dc0b-4fca-9212-10cdd4375a07	Community integration	Social	\N	t	2025-09-08 00:03:47.849171+03
5d143c7a-aaca-4f9a-b1c2-5957b0a9e346	Trauma recovery	Mental Health	\N	t	2025-09-08 00:03:47.849171+03
d8d8b1f9-8839-4438-a748-09f17017cd0c	Anger management	Behavioral	\N	t	2025-09-08 00:03:47.849171+03
23f12f93-c3e4-48ce-9b4f-6143e2e02aa6	Communication skills	Social	\N	t	2025-09-08 00:03:47.849171+03
44c42ad1-e990-40be-b902-e4ebab4f8636	Goal setting and planning	Life Skills	\N	t	2025-09-08 00:03:47.849171+03
7f2d8fef-1c7e-4505-ac01-f30b52f17532	Stress reduction techniques	Mental Health	\N	t	2025-09-08 00:03:47.849171+03
78d4074f-ec31-480a-ab70-6feba6906c38	Anxiety management	\N	\N	t	2025-11-05 21:38:06.52444+03
a79169b4-bdfd-4d3d-88aa-5942ca8f089a	Self-esteem building	\N	\N	t	2025-11-05 21:38:12.336894+03
b48b66d2-6932-4afa-9f24-8fa9ce0c35e8	Educational goals	Academic	\N	t	2025-09-08 00:03:47.849171+03
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, password_hash, role, first_name, last_name, is_active, last_login_at, created_at, updated_at) FROM stdin;
0f9f1311-91b7-4e4c-8330-0197264792de	msmith	mary.smith@agency.com	$2a$06$dqaQ0E0y.JCVx7GgPBN5x.s1eWeobevx4BWCga7Q4PZKLKaXxYHZy	peer_support	Mary	Smith	t	\N	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03
73496734-c379-43dd-a796-638f741e3694	bwilson	bob.wilson@agency.com	$2a$06$4.BZE10hmDSYyjdAPRaUZOdi/ia29HC/BWpKGrTr6WcxnKUKVDABy	peer_support	Bob	Wilson	t	\N	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03
3d721fc1-e812-49fa-848e-b5009a264a7c	sjohnson	sarah.johnson@agency.com	$2a$06$uhtcr6115xIJsOWK6U7zYeK/rkzpGrDoHhG/dC0kFWWahGBWM01Ty	peer_support	Sarah	Johnson	t	\N	2025-09-08 00:03:47.849171+03	2025-09-08 00:03:47.849171+03
28224a49-6863-420f-9045-58a433948c9b	jdoe	john.doe@agency.com	$2a$06$4zzthCgUkkWMtunSeD0ZYuCuIVgxFh/dvvA2Xu/z99kJ97Wd9HMpu	peer_support	John	Doe	t	2025-09-14 12:10:32.050657+03	2025-09-08 00:03:47.849171+03	2025-09-14 12:10:32.050657+03
76c00b5d-8300-4482-934c-53496deed884	admin	admin@agency.com	$2a$06$PE2lAeHdL6kGQJIgg8skuu6AjT/dcM/e7dOeKwiDPlmfMdpoyEifa	admin	System	Administrator	t	2025-11-05 21:27:05.652154+03	2025-09-08 00:03:47.849171+03	2025-11-05 21:27:05.652154+03
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: session_locations session_locations_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_locations
    ADD CONSTRAINT session_locations_name_key UNIQUE (name);


--
-- Name: session_locations session_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_locations
    ADD CONSTRAINT session_locations_pkey PRIMARY KEY (id);


--
-- Name: session_notes session_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_notes
    ADD CONSTRAINT session_notes_pkey PRIMARY KEY (id);


--
-- Name: session_objectives session_objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_objectives
    ADD CONSTRAINT session_objectives_pkey PRIMARY KEY (id);


--
-- Name: treatment_objectives treatment_objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treatment_objectives
    ADD CONSTRAINT treatment_objectives_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_audit_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_created ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_table_record; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_table_record ON public.audit_logs USING btree (table_name, record_id);


--
-- Name: idx_audit_logs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_user ON public.audit_logs USING btree (user_id);


--
-- Name: idx_clients_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clients_active ON public.clients USING btree (is_active);


--
-- Name: idx_clients_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clients_created_by ON public.clients USING btree (created_by);


--
-- Name: idx_clients_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clients_name ON public.clients USING btree (first_name, last_initial);


--
-- Name: idx_session_notes_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_notes_client ON public.session_notes USING btree (client_id);


--
-- Name: idx_session_notes_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_notes_created ON public.session_notes USING btree (created_at);


--
-- Name: idx_session_notes_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_notes_date ON public.session_notes USING btree (session_date);


--
-- Name: idx_session_notes_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_notes_status ON public.session_notes USING btree (status);


--
-- Name: idx_session_notes_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_notes_user ON public.session_notes USING btree (user_id);


--
-- Name: idx_session_objectives_objective; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_objectives_objective ON public.session_objectives USING btree (objective_id);


--
-- Name: idx_session_objectives_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_objectives_session ON public.session_objectives USING btree (session_note_id);


--
-- Name: idx_users_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_active ON public.users USING btree (is_active);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: clients update_clients_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_clients_updated_at BEFORE UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: session_notes update_session_notes_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_session_notes_updated_at BEFORE UPDATE ON public.session_notes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: clients clients_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: session_notes session_notes_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_notes
    ADD CONSTRAINT session_notes_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: session_notes session_notes_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_notes
    ADD CONSTRAINT session_notes_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.session_locations(id);


--
-- Name: session_notes session_notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_notes
    ADD CONSTRAINT session_notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: session_objectives session_objectives_objective_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_objectives
    ADD CONSTRAINT session_objectives_objective_id_fkey FOREIGN KEY (objective_id) REFERENCES public.treatment_objectives(id);


--
-- Name: session_objectives session_objectives_session_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_objectives
    ADD CONSTRAINT session_objectives_session_note_id_fkey FOREIGN KEY (session_note_id) REFERENCES public.session_notes(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict vtXgumJufkuNrEQ0qh2H8u9gfPz3S0pjcAqIVswgwvwfdbcg6FIrqpnwg88Xfus

